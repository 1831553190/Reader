package com.example.myapplication.view;

public class MyPoint {
    float x;
    float y;

    public MyPoint(float x, float y) {
        this.x = x;
        this.y = y;
    }

}
